
<nav class = "css_sobre">
    <h2>Por que a Academia Mataraca é diferente?</h2>
    <h3 class="letra_sobre">Acreditamos que o exercício é para todos! <br> Por isso, proporcionamos a melhor infraestrutura, equipamentos de última geração <br> e professores
         altamente  qualificados para que cada aluno alcance sua melhor versão.</h3>

    <h2>Fidelidade e adesão ZERO</h2>
    <h3 class="letra_sobre">Na Selfit, você começa porque é diferente e fica porque funciona! <br> Não cobramos absolutamente nada pela adesão e você permanece com a
         <br> gente pelo tempo que desejar. Assim, você foca no que importa: <br> cuidar da sua saúde.</h3>
    
    <h2>Modalidades exclusivas </h2>

    <h3 class="letra_sobre">Espaços planejados para promover uma vida mais ativa, com maior mobilidade, possibilitando <br> ao aluno se
         movimentar, tonificar seus músculos, perder peso e ganhar massa magra.

    </h3>
    
    
    
    
    
    
</nav>
