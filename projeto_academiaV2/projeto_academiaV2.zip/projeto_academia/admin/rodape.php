<link rel="stylesheet" href="style-admin.css">
</div> <!-- fim conteúdo -->

<div id="rodape">
    <p>Painel Admin - Todos os direitos reservados</p>
</div>

</body>
</html>
