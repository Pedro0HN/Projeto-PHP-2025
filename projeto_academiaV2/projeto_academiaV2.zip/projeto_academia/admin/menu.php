<link rel="stylesheet" href="style-admin.css">
<div id="menu">
    <a href="index.php">Início</a>
    <a href="index.php?pg=listar-assinaturas">Listar Clientes</a>
</div>

<div id="conteudo">
