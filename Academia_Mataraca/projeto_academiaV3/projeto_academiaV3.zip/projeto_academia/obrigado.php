<?php
// Nenhum processamento necessário aqui
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Assinatura Concluída</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="obrigado_box">
        <h1>Assinatura realizada com sucesso!</h1>
        <p>Obrigado por se cadastrar. Sua assinatura foi registrada no sistema.</p>

        <a href="index.php" class="botao_voltar_home">Voltar para a página inicial</a>
    </div>

</body>
</html>
