<?php
session_start();

if (!isset($_SESSION['aluno_id'])) {
    header("Location: area_do_aluno.php");
    exit();
}
?>

<h1>Bem-vindo, <?php echo $_SESSION['aluno_nome']; ?>!</h1>
<p>Aqui você verá seus treinos, horários e pagamentos.</p>
