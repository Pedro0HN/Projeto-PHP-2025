<footer class="rodape">
   
    <h3>Contato</h3>

    <h2>Fale comigo agora: </h2>

    <form action="mensagem" method="post">
        <label for="text">Seu nome: </label>
        <input type="text" name="nome" id="nome">
        <label for="text">Mensagem: </label>
        <input type="text" name="mensagem" id="mensagem">
        <input type="submit" value="Enviar">

    </form>
    <a href="#topo">Ir para o topo</a>


    <p>© 2025 Academia Mataraca — Todos os direitos reservados</p>
</footer>


</body>
</html>