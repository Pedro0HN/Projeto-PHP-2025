<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="style-admin.css"> 
</head>
<body>

<div id="topo">
    <h1>PAINEL ADMINISTRATIVO</h1>
</div>
