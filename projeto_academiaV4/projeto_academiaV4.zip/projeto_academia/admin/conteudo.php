<link rel="stylesheet" href="style-admin.css">
<h2>Bem-vindo ao Painel Administrativo</h2>
<p>Use o menu acima para gerenciar cadastros.</p>
