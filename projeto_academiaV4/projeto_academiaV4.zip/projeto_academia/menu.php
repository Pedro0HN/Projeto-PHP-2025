
<ul class="menu">
    <li><a href="?pg=conteudo">Home</a></li>
    <li><a href="?pg=sobre">Sobre</a></li>
    <li><a href="?pg=planos">Planos</a></li>
    <li><a href="?pg=horarios">Horários</a></li> 
    <li><a href="https://web.whatsapp.com/" target="_blank">Fale Comigo</a></li>
    <li><a href="?pg=areadoaluno">Area do Aluno</a></li>
</ul>



